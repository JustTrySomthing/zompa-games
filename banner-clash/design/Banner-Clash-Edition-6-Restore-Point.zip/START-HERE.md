# Banner Clash • Pre-build restore point • Edition 6

Open Banner-Clash-Rulebook.md first. The player instructions, nine-card reference, match flow and multiplayer decisions at the front are the development baseline. The later audit sections record how the design was tested. Historical simulation results describe the model used at that time. Use the final player rules when implementing a feature.

## Resume development

Banner Clash belongs in the existing Zompa game collection. Inspect the current project and a shipped game for its package, invitation flow, top bar, pause, call and resume conventions before choosing implementation details. This archive captures the game design and validation sources. The host application and its build environment are separate dependencies.

Build one rules implementation shared by Solo, Pass & Play and Online. Start with a complete playable match in Pass & Play, including the secret handoff, reveal, final score inspection and rematch. Use the same board, sizing, help, controls and scoring in all modes. Then connect the Solo opponent and the host’s online invitation, persistence and resume flows. Carry the small “?” How to Play control into the shared game conventions and developer documentation.

## Baseline to preserve

Each player has two copies of nine cards and a private four-card opening hand containing a character. A battle has five alternating open turns per player and one secret reinforcement or Hold per player. First to three banners wins. The route is Bridge → Watchtower → Grove → Watchtower → Bridge. Score 2–2 always means the final battle. Consult the rulebook for bonuses, ties, shared awards, deck recycling and exact cleanup order.

## Verification and outstanding work

From this folder, run the two commands below using Node.js and Python 3. These seeded design checks use their standard runtimes. Compare output with checks/verified-output.txt. To verify archived files after extraction, run the checksum command in the same folder.

    node checks/matches.cjs
    python3 checks/reverse.py
    sha256sum -c SHA256SUMS

The game implementation, art and APK are future work. The first playable build must establish match duration, readability and first-time comprehension. Two-device tests must establish fair private reveals, interruption and reconnection behavior, resignation ordering and exactly one recorded outcome. The rulebook includes specific cases and simulation limitations.

## Handoff for a new conversation

“Resume Banner Clash in the Zompa project from the Edition 6 pre-build restore point. Use the enclosed rulebook as the design baseline and its acceptance cases to verify the playable implementation.”
