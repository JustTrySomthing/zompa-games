let seed=90217;function rnd(){seed=(Math.imul(1664525,seed)+1013904223)>>>0;return seed/4294967296}
function shuffle(a){for(let i=a.length-1;i>0;i--){let j=Math.floor(rnd()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
const power=[3,2,2,4,2,3,0,0,0],deck=()=>Array.from({length:18},(_,i)=>i%9);
function player(){let d=shuffle(deck()),h=d.splice(0,4);if(h.every(c=>c>=6)){let j=d.findIndex(c=>c<6),one=d.splice(j,1);d=shuffle(d.concat(h));h=one.concat(d.splice(0,3))}return {h,d,x:[],b:[]}}
function draw(p){if(!p.d.length)p.d=shuffle(p.x.splice(0));if(p.d.length)p.h.push(p.d.pop())}
function refill(p){while(p.h.length<4&&(p.d.length+p.x.length))draw(p)}
function score(b){let v=[0,0,0];for(let [c,l,r] of b){let g=b.filter(t=>t[1]==l);v[l]+=power[c]+r+(c==2&&g.filter(t=>t[0]==2).length==2?2:0)+(c==4&&g.length>1?1:0)+(c==5&&g.length==1?1:0)}return v}
function verify(p){
let cards=p.h.concat(p.d,p.x,p.b.map(u=>u[0]));
if(p.h.length>4||deck().some(c=>cards.filter(v=>v==c).length!=2))throw Error('inventory');
for(let l=0;l<3;l++){
let group=p.b.filter(u=>u[1]==l), kinds=group.map(u=>u[0]);
let expected=group.reduce((v,[c,loc,r])=>v+power[c]+r,0)
+(kinds.filter(c=>c==2).length==2?4:0)
+(group.length>1?kinds.filter(c=>c==4).length:0)
+(group.length==1&&kinds[0]==5?1:0);
if(score(p.b)[l]!==expected)throw Error('strength');
}}
let early=0;function game(n,styles,s){let P=[player(),player()],wins=[0,0];const route=[0,1,2,1,0];for(let k=0;k<5;k++){let f=route[k];const next=k<4 && !(wins[0]==2 && wins[1]==2)?route[k+1]:null;if(k<4 && next===null)early++;for(let t=0;t<2*n;t++){let id=(t+k)%2,p=P[id],o=P[1-id],style=styles[id],best=-Infinity,chosen;
function consider(card,b,e,kind){let a=score(b),z=score(e),lead=a[f]-z[f],future=next===null?0:a[next]-z[next];
let val=(style=='rush'?lead:6*Math.tanh(lead/6)+0.48*future)+0.06*(a.reduce((x,y)=>x+y)-z.reduce((x,y)=>x+y))+(kind=='swap'?0.09:0)+(kind=='play'?0.12:0)+rnd()*.18;
if(style=="random")val=rnd();if(style=="pass")val=kind=="pass"?1:0;if(val>best){best=val;chosen={card,b,e,kind}}}
consider(-1,p.b,o.b,'pass');
function moved(b,i,l){return b.map((u,j)=>i==j?[u[0],l,u[2]]:u)}
for(let [i,[c,loc]] of p.b.entries())for(let l=0;l<3;l++)if(c!=3&&loc!=l&&(c==1||Math.abs(loc-l)==1))consider(-1,moved(p.b,i,l),o.b,'move');
for(let c of new Set(p.h)){if(p.d.length+p.x.length)consider(c,p.b,o.b,'swap');
if(c<6){for(let l=0;l<3;l++)consider(c,p.b.concat([[c,l,0]]),o.b,'play');continue}
let b=c==6?o.b:p.b;for(let [i,[u,loc,r]] of b.entries()){if(c==7){consider(c,b.map((v,j)=>j==i?[u,loc,r+2]:v),o.b,'play');continue}
for(let l=0;l<3;l++)if(loc!=l&&u!=3&&(c==8||u!=0&&Math.abs(l-loc)==1)){let m=moved(b,i,l);consider(c,c==6?p.b:m,c==6?m:o.b,'play')}}}
let {card,b,e,kind}=chosen;actions[card<0?kind:kind== 'swap'?'swap':'card'+card]=(actions[card<0?kind:kind=='swap'?'swap':'card'+card]||0)+1;p.b=b;o.b=e;if(card>=0){p.h.splice(p.h.indexOf(card),1);if(kind=='swap')draw(p);if(kind=='swap'||card>=6)p.x.push(card);refill(p)}
P.forEach(verify);
}
let a=P.map(p=>score(p.b)),base=a[0][f]-a[1][f];let delta=P.map((p,i)=>{let chars=p.h.filter(c=>c<6).sort((x,y)=>power[y]-power[x]);let lead=base*(i?-1:1);if(styles[i]=="pass"||!chars.length||(styles[i]=='save'&&Math.abs(lead)>4))return 0;let c=chars[0];p.h.splice(p.h.indexOf(c),1);p.x.push(c);return power[c]});
let end=base+delta[0]-delta[1];s.b++;if(Math.sign(end)!=Math.sign(base))s.flip++;if(!end){s.tie++;end=a[0].reduce((x,y)=>x+y)-a[1].reduce((x,y)=>x+y)-base}
let other=(f+1)%3,third=(f+2)%3;let actual=Math.sign(base+delta[0]-delta[1])||Math.sign(a[0][other]+a[0][third]-a[1][other]-a[1][third]);if(actual!=Math.sign(end))throw Error("award");if(end>=0)wins[0]++;if(end<=0)wins[1]++;
for(let p of P){for(let u of p.b.filter(u=>u[1]==f))p.x.push(u[0]);p.b=p.b.filter(u=>u[1]!=f).map(([c,l])=>[c,l,0]);refill(p);if(deck().some(c=>p.h.concat(p.d,p.x,p.b.map(u=>u[0])).filter(v=>v==c).length!=2))throw Error('count')}
if(Math.max(...wins)>=3){s.lengths[k]++;return Math.sign(wins[0]-wins[1])}}
throw Error('unfinished')}

let actions={};for(let [A,B] of [['save','save'],['save','rush'],['save','plan'],['random','random'],['pass','pass']]){
let s={lengths:[0,0,0,0,0],b:0,tie:0,flip:0},N=A=='pass'?100:2000,win=0,draws=0;for(let k=0;k<N;k++){let r=game(5,k%2?[B,A]:[A,B],s);win+=(k%2?-r:r)>0;draws+=r==0}
if(A=='pass'&&(draws!=N||s.lengths[2]!=N))throw Error('pass');console.log(A,B,JSON.stringify(s),win,draws)}
console.log({early,actions})
function paths(a,b,k){if(Math.max(a,b)==3){if(k<3||k>5)throw Error('length');return 1}return paths(a+1,b,k+1)+paths(a,b+1,k+1)+paths(a+1,b+1,k+1)}console.log('paths',paths(0,0,0));
