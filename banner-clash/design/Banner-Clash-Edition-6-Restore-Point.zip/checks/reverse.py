from itertools import product,combinations,permutations
from collections import Counter
aw=((1,0),(0,1),(1,1))
def back(a,b):
 if (a,b)==(0,0): return {()}
 return {h+(w,) for w in aw for x,y in [(a-w[0],b-w[1])] if 0<=x<3 and 0<=y<3 for h in back(x,y)}
hist=set().union(*(back(a,b) for a,b in product(range(4),repeat=2) if max(a,b)==3))
def forward(h,a,b):
 if max(a,b)==3:return {h}
 return set().union(*(forward(h+(w,),a+w[0],b+w[1]) for w in aw))
assert hist==forward((),0,0)
for h in hist:assert tuple((b,a) for a,b in h) in hist
print('reverse histories',Counter(map(len,hist)))
hands=list(combinations(range(18),4));bad=[h for h in hands if all(i%9>=6 for i in h)]
assert all(any(i%9<6 and i not in h for i in range(18)) for h in bad)
print('initial hands',len(hands),'need redraw',len(bad))
# Compare two score formulations from both seats across bonuses already included in margins.
n=0
for flag,secondary,x,y in product(range(-12,13),range(-12,13),(0,2,3,4),(0,2,3,4)):
 def award(f,s,x,y):
  a=(f+x,s);b=(y,0)
  return (int(a>=b),int(b>=a))
 actual=award(flag,secondary,x,y)
 assert actual==award(-flag,-secondary,y,x)[::-1]
 diff=flag+x-y or secondary
 assert actual==(int(diff>=0),int(diff<=0))
 n+=1
print('award comparisons',n)
